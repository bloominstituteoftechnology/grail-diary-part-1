//
//  ViewController.swift
//  GrailDiary
//
//  Created by user162867 on 12/10/19.
//  Copyright © 2019 user162867. All rights reserved.
//

import UIKit

class POIsTableViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

