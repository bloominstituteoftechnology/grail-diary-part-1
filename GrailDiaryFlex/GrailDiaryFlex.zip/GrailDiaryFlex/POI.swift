//
//  POI.swift
//  GrailDiaryFlex
//
//  Created by admin on 8/14/19.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation

struct POI {
    let location: String
    let country: String
    var clues: [String]
}
