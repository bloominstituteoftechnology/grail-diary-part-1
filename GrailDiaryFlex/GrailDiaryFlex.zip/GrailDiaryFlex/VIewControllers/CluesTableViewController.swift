//
//  CluesTableViewController.swift
//  GrailDiaryFlex
//
//  Created by admin on 8/13/19.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class CluesTableViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

